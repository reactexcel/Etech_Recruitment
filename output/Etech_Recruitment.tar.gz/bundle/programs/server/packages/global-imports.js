/* Imports for global scope */

MongoInternals = Package.mongo.MongoInternals;
Mongo = Package.mongo.Mongo;
Tracker = Package.tracker.Tracker;
Deps = Package.tracker.Deps;
ReactMeteorData = Package['react-meteor-data'].ReactMeteorData;
BlazeToReact = Package['thereactivestack:blazetoreact'].BlazeToReact;
Email = Package.email.Email;
EmailInternals = Package.email.EmailInternals;
Meteor = Package.meteor.Meteor;
global = Package.meteor.global;
meteorEnv = Package.meteor.meteorEnv;
WebApp = Package.webapp.WebApp;
main = Package.webapp.main;
WebAppInternals = Package.webapp.WebAppInternals;
_ = Package.underscore._;
DDP = Package['ddp-client'].DDP;
DDPServer = Package['ddp-server'].DDPServer;
LaunchScreen = Package['launch-screen'].LaunchScreen;
Symbol = Package['ecmascript-runtime'].Symbol;
Map = Package['ecmascript-runtime'].Map;
Set = Package['ecmascript-runtime'].Set;
Promise = Package.promise.Promise;
Accounts = Package['accounts-base'].Accounts;
Blaze = Package.ui.Blaze;
UI = Package.ui.UI;
Handlebars = Package.ui.Handlebars;
Spacebars = Package.spacebars.Spacebars;
Autoupdate = Package.autoupdate.Autoupdate;
HTML = Package.htmljs.HTML;

