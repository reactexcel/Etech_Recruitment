import { combineReducers } from 'redux-immutable'
import entities from './entities'
export default combineReducers({
	entities
})
