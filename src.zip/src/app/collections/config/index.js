import { Mongo } from 'meteor/mongo';

const Config = new Mongo.Collection("config");

export default Config;
