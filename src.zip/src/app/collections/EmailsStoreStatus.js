import { Mongo } from 'meteor/mongo'

const EmailsStoreStatus = new Mongo.Collection("emails_store_status")

export default EmailsStoreStatus


