import {Meteor} from 'meteor/meteor';

import  'app/collections';


